
Fake News Detection using Machine Learning

This project detects whether a news article is Fake or Real using Natural Language Processing and Machine Learning.

Technologies:
Python, Pandas, Scikit-learn, TF-IDF

Steps:
1. Load dataset
2. Preprocess text
3. Convert text to numerical vectors using TF-IDF
4. Train Logistic Regression model
5. Predict fake or real news

Author: S Amudhan
