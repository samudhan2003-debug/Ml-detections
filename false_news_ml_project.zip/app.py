
import pickle

model = pickle.load(open("model/fake_news_model.pkl","rb"))
vectorizer = pickle.load(open("model/vectorizer.pkl","rb"))

news = input("Enter news headline: ")
news_vector = vectorizer.transform([news])
prediction = model.predict(news_vector)

print("Prediction:", prediction[0])
